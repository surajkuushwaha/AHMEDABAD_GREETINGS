@extends('admin/master')
<?php
$a = "suraj";
?>

@section('title',$a)

@section('header') @parent @endsection
@section('content')
@endsection


@section('footer') @parent @endsection
