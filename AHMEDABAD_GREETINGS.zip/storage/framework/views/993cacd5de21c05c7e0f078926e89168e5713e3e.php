<?php
$a = "suraj";
?>

<?php $__env->startSection('title',$a); ?> <?php $__env->startSection('header'); ?> ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231## <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="container-flude">
    <div class="row mt-10">
        <div class="col-sm-2">
            
        </div>
        <div class="col-sm-8">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Address_id</th>
                        <th scope="col">street</th>
                        <th scope="col">Pin_code</th>
                        <th scope="col">city</th>
                        <th scope="col">state</th>
                        <th scope="col">created_at</th>
                        <th scope="col">created_at</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i->Address_id); ?></th>
                        <td><?php echo e($i->street); ?></td>
                        <td><?php echo e($i->Pin_code); ?></td>
                        <td><?php echo e($i->city); ?></td>
                        <td><?php echo e($i->state); ?></td>
                        <td><?php echo e($i->created_at); ?></td>
                        <td><?php echo e($i->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
        <div class="col-sm-2"></div>
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('footer'); ?> ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f## <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/Admin/Address.blade.php ENDPATH**/ ?>