<?php
$a = "suraj";
?>

<?php $__env->startSection('title',$a); ?> <?php $__env->startSection('header'); ?> ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231## <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <table id="datatable" class="table border border-info mt-3">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">name</th>
                        <th scope="col">email</th>
                        <th scope="col">address</th>
                        <th scope="col">phone_no</th>
                        <th scope="col">created_at</th>
                        <th scope="col">updated_at</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i->id); ?></th>
                        <td><?php echo e($i->name); ?></td>
                        <td><?php echo e($i->email); ?></td>
                        <!-- data -->
                        
                        <td><?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i->address_id == $j->Address_id): ?>
                            <?php echo e($j->street); ?>

                            <?php echo e($j->city); ?>

                            <?php echo e($j->state); ?>

                            <?php echo e($j->Pin_code); ?>

                            <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                        <td><?php echo e($i->Phone_no); ?></td>
                        <td><?php echo e($i->created_at); ?></td>
                        <td><?php echo e($i->updated_at); ?></td>
                        <td>
                            <form action="user/edituser" method="POST">
                                <?php echo csrf_field(); ?>
                                <button
                                    type="submit"
                                    class="btn btn-light"
                                    name="bt"
                                    value="<?php echo e($i->id); ?>"
                                >
                                    <img
                                        src="<?php echo e(asset('svg/edit.svg')); ?>"
                                        alt="ds"
                                        height="40"
                                        width="30"
                                    />
                                </button>
                            </form>
                        </td>
                        <td>
                            <form action="user/deleteuse" method="POST">
                            <?php echo csrf_field(); ?>
                                <button
                                    class="btn btn-danger"
                                    data-toggle="modal"
                                    data-target="#edit"
                                    value="<?php echo e($i->id); ?>"
                                    name="bt"
                                >
                                    <img
                                        src="<?php echo e(asset('svg/delete.svg')); ?>"
                                        alt="ds"
                                        height="40"
                                        width="30"
                                    />
                                </button>
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Modal -->
        </div>
        <div class="col-sm-2"></div>
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('footer'); ?> ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f## <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/Admin/user.blade.php ENDPATH**/ ?>