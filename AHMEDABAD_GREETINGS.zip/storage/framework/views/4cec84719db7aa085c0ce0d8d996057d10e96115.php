<?php
$a = "suraj";
?>


<?php $__env->startSection('css'); ?> 
<link rel="stylesheet"href="<?php echo e(asset('css/show.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title',$a); ?>
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('header'); ?> ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="some">
            <img src="<?php echo e(asset('svg/circles.svg')); ?>" alt="dots" />
            <h1>Dots</h1>
        </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?> ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f## <?php $__env->stopSection(); ?>

<?php echo $__env->make('greetings/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/temp.blade.php ENDPATH**/ ?>