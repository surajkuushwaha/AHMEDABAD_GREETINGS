<!-- file upload not working -->
<!-- <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>upload</title>
    </head>
    <body>
        <form action="upload" method="post" enctype="multipart/form-data">
            <input type="file" name="img" />
            <?php echo csrf_field(); ?>
            <button>upload img</button>
        </form>
    </body>
</html> -->
<!-- select from table -->
<!-- <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>suraj</title>
    </head>
    <body>
        <table border="1">
            <tr>
                <th>id</th>
                <th>name</th>
                <th>enrollmentno</th>
            </tr>
            notes me dekho::database
        </table>
    </body>
</html> -->
<!-- insert from form  -->
<!-- <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>suraj</title>
    </head>
    <body>
        <form action="insert" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="naam" /><br />
            <input type="text" name="enroll" placeholder="address" />
            <button type="submit">submit</button>
        </form>
    </body>
</html> -->

<!-- update data -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>update</title>
    </head>
    <body>
        <form action="update1" method="post">
            <?php echo csrf_field(); ?>
            <input type="radio" name="action" value="insert" />
            <label for="insert">insert</label>
            <input type="radio" name="action" value="update" />
            <label for="update">update</label>
            <input type="radio" name="action" value="delete" />
            <label for="update">delete</label>

            <select name="id">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($i->id); ?>"><?php echo e($i->id); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br />
            <input type="text" name="name" /><br />
            <input type="text" name="enroll" /><br />
            <button type="submit">Update</button>
        </form>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/upload.blade.php ENDPATH**/ ?>