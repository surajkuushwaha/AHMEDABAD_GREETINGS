<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">   
    <link
            rel="stylesheet"
            href="<?php echo e(asset('css/style.css')); ?>"
            type="text/css"
        />
        <?php echo $__env->yieldContent('css'); ?>
        <title><?php echo $__env->yieldContent('title'); ?></title>
    </head>

    <body>
        <?php $__env->startSection('header'); ?>
        <nav>
            <a href="#">
                <img class="logo" src="<?php echo e(asset('image/logo.png')); ?>"/>
            </a>
            <div class="hamburger">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
            <ul class="nav-links">
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Projects</a></li>
            </ul>
        </nav>
        <script src="<?php echo e(asset('js/app1.js')); ?>"></script>
        <?php echo $__env->yieldSection(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        
        <?php $__env->startSection('footer'); ?>
        <div class="footer">
            <h1>Footer side</h1>
        </div>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/greetings/master.blade.php ENDPATH**/ ?>