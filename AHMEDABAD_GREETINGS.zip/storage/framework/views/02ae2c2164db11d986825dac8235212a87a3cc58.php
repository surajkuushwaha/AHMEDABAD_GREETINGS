<?php
$a = $data[0];
?>

<?php $__env->startSection('title',$a->name); ?> <?php $__env->startSection('header'); ?> ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231## <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/finaledit" method="POST">

                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($i->id); ?>" name="id">
                            <div class="form-group">
                                <label for="inputEmail4">Email</label>
                                <input type="email" class="form-control" id="inputEmail4" value="<?php echo e($i->email); ?>" placeholder="<?php echo e($i->email); ?>" name="email">
                            </div>
                            <div class="form-group">
                                <label for="formGroupExampleInput">Name</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" value="<?php echo e($i->name); ?>" placeholder="<?php echo e($i->name); ?>" name="name">
                            </div>
                            <input type="hidden" value="<?php echo e($i->address_id); ?>" name="address_id">
                            <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i->address_id == $j->Address_id): ?>
                            <div class="form-group">
                                <label for="inputAddress2">Address</label>
                                <input type="text" class="form-control" id="inputAddress2" value="<?php echo e($j->street); ?>" name="address_street" placeholder="<?php echo e($j->street); ?>">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="inputCity">City</label>
                                    <input type="text" class="form-control" id="inputCity" value="<?php echo e($j->city); ?>" placeholder="<?php echo e($j->city); ?>" name="address_city">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="inputState">State</label>
                                    <input type="text" class="form-control" value="<?php echo e($j->state); ?>" placeholder="<?php echo e($j->state); ?>" name="address_State">
                                    
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="inputZip">Pin code</label>
                                    <input type="text" class="form-control" value="<?php echo e($j->Pin_code); ?>" placeholder="<?php echo e($j->Pin_code); ?>" name="address_Pin_code">
                                </div>
                            </div>
                            <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="form-group">
                                <label for="formGroupExampleInput2">Phone No</label>
                                <input type="text" class="form-control" id="formGroupExampleInput2" value="<?php echo e($i->Phone_no); ?>" placeholder="<?php echo e($i->Phone_no); ?>" name="phone">
                            </div>
                   
                    <button type="submit" class="btn btn-primary">Update</button>
                    
                   
                    
        </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--             
            <table id="datatable" class="table border border-info mt-3">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">name</th>
                        <th scope="col">email</th>
                        <th scope="col">address</th>
                        <th scope="col">phone_no</th>
                        <th scope="col">created_at</th>
                        <th scope="col">updated_at</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i->id); ?></th>
                        <td><?php echo e($i->name); ?></td>
                        <td><?php echo e($i->email); ?></td>
                        <td><?php echo e($i->address); ?></td>
                        <td><?php echo e($i->phone_no); ?></td>
                        <td><?php echo e($i->created_at); ?></td>
                        <td><?php echo e($i->updated_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table> -->

           
        </div>
        <div class="col-sm-2">
            
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?> <?php $__env->startSection('footer'); ?> ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f## <?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/Admin/Edituser.blade.php ENDPATH**/ ?>