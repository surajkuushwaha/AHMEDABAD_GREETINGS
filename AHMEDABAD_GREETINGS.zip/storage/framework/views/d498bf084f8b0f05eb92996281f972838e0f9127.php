<!DOCTYPE html>
<html>
    <head>
        <link
            rel="stylesheet"
            href="<?php echo e(asset('css/style.css')); ?>"
            type="text/css"
        />
        <title><?php echo $__env->yieldContent('title'); ?></title>
    </head>

    <body>
        <?php $__env->startSection('header'); ?>
        <nav>
            <div class="hamburger">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
            <ul class="nav-links">
                <li><a href="/">Home</a></li>
                <li><a href="/Contact">Contact</a></li>
                <li><a href="/Projects">Projects</a></li>
            </ul>
        </nav>

        <section class="landing">
            <img src="<?php echo e(asset('svg/circles.svg')); ?>" alt="dots" />
            <h1>Dots</h1>
        </section>

        <script src="<?php echo e(asset('js/app1.js')); ?>"></script>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\AHMEDABAD_GREETINGS\resources\views/master.blade.php ENDPATH**/ ?>